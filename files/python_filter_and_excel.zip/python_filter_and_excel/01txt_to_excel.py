import pandas as pd
import re

# Define las rutas de los archivos de entrada y salida
input_file_path = '212108020006.txt'
output_file_path = '212108020006.xlsx'

# Lee el archivo de texto en un DataFrame de pandas, usando espacios múltiples como separadores
with open(input_file_path, 'r') as file:
    lines = file.readlines()

# Divide cada línea en columnas usando espacios múltiples como separadores
df = pd.read_csv(input_file_path, sep=r'\s+', header=None)

# Guarda el DataFrame en un archivo Excel
df.to_excel(output_file_path, index=False, header=False)

print(f'El archivo se ha convertido a Excel y se ha guardado en {output_file_path}')