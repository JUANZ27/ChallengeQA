input_file = 'DATACOLDVIEW06_10K.txtpage_1_to_13 1.txt'
output_file = '212108020006.txt'
search_text = '212108020006'

with open(input_file, 'r') as file:
    lines = file.readlines()

filtered_lines = [line for line in lines if search_text in line]

with open(output_file, 'w') as file:
    file.writelines(filtered_lines)

print(f"Filtrado completado. Las líneas que contienen '{search_text}' se han guardado en '{output_file}'.")